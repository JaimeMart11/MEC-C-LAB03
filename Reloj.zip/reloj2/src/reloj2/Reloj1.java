import javax.swing.*;
import java.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;

public class Reloj1 extends JFrame {
    private int Segundos;
    private int Alarma;
    private int DespuesAlarma;
    private JLabel hora;
    private JLabel alarma;
    private final Timer tiempo;

    public Reloj1() {
        super("RELOJ");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        alarma = new JLabel("Alarma no establecida");
        alarma.setFont(new Font("Times", Font.PLAIN, 30));

        hora = new JLabel("00:00:00");
        hora.setFont(new Font("Times", Font.BOLD, 30));

        JPanel seccion = new JPanel(new BorderLayout());
        seccion.add(hora, BorderLayout.CENTER);
        seccion.add(alarma, BorderLayout.SOUTH);    
        
        this.add(seccion);
        this.pack();
        this.setVisible(true);
        
        Segundos = 0;
        Alarma = 0;
        DespuesAlarma = 0;

        tiempo = new Timer(1000, (ActionEvent a) -> {
            
            Segundos++;
            String hora1 = new SimpleDateFormat("00:mm:ss").format(new Date(Segundos * 1000));
            hora.setText(hora1);
            
                if(Segundos >= Alarma && Alarma > 0) {
                    alarma.setText("Alarma");
                    DespuesAlarma++;
                }
        });
        
        tiempo.start();
    }
    
    public static void main(String[] args) {
        Reloj cronometro = new Reloj();
        cronometro.establecerAlarma(0, 10); 
    }
    
     public void establecerAlarma(int minutos, int segundos) {
        Alarma = minutos + segundos;
        alarma.setText("La alarma esta colocada para: " + minutos + "minutos " + segundos + "segundos");
    }
}